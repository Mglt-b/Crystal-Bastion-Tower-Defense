ameliorations = {
    "Magique": [
        {
            "cout_amelioration": 50,
            "temps_entre_attaque": 1.0,
            "degats_physiques": 20,
            "range": 100,
            "color": [0.5, 0.5, 0.5, 1],
        },
        {
            "cout_amelioration": 100,
            "temps_entre_attaque": 0.8,
            "degats_physiques": 30,
            "range": 120,
            "color": [0.7, 0.5, 0.5, 1],
        },
        # ... Plus de niveaux d'amélioration
    ],
    # ... Autres types de tours
}
